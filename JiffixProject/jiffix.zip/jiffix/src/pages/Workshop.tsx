import React from "react";
import MainWorkshop from "../components/Book Demo/MainWorkshop";

const Workshop = () => {
  return <MainWorkshop />;
};

export default Workshop;
