import React from "react";
import Booking from "../components/Book Demo/Booking";

const Businesses = () => {
  return (
    <div className="font-monts">
      <Booking />
    </div>
  );
};

export default Businesses;
